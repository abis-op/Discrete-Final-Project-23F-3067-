#ifndef COMBINATOR_H
#define COMBINATOR_H

class Combinator 
{
public:
    static void createStudentGroups(int totalStudents, int groupSize);
    
private:
    static void buildGroups(int start, int total, int needed, 
                           int* currentGroup, int currentSize);
    static void displayGroup(int* group, int size);
};

#endif