#ifndef CLI_INTERFACE_H
#define CLI_INTERFACE_H

class CLIInterface {
public:
    void displayMainMenu();
    void displayHeader();
    int getUserChoice();
    void handleMenuChoice(int choice);
    void run();
    
private:
    void displayModuleMenu();
    void displayDemoMenu();
};

#endif