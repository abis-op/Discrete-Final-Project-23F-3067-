#ifndef CONSISTENCY_CHECKER_H
#define CONSISTENCY_CHECKER_H

#include <string>
#include <iostream>

class ConsistencyChecker {
private:
    static const int MAX_VIOLATIONS = 100;
    std::string violations[MAX_VIOLATIONS];
    int violationCount;

public:
    ConsistencyChecker();

    void addViolation(const std::string& violation);
    void checkCourseOverlap(int schedule[][10], int numCourses);
    void checkPrerequisiteViolation(int prereq[][2], int prereqCount, int completed[], int completedCount);
    void checkFacultyOverload(int facultyCourses[][10], int facultyCount);
    void checkRoomConflicts(int rooms[][24], int roomCount);

    void displayViolations();
};

#endif
