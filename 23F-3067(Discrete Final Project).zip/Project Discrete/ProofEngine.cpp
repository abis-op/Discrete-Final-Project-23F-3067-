#include "ProofEngine.h"
#include <iostream>

ProofEngine::ProofEngine() {
    stepCount = 0;
}

void ProofEngine::addProofStep(const std::string& step) {
    if (stepCount < MAX_STEPS) {
        proofSteps[stepCount] = step;
        stepCount++;
    }
}

void ProofEngine::addHeader(const std::string& title) {
    addProofStep("=== " + title + " ===");
}

void ProofEngine::addConclusion(bool isValid) {
    addProofStep("CONCLUSION: " + std::string(isValid ? "VALID" : "INVALID"));
}

void ProofEngine::verifyPrerequisiteChain(int courses[], int size) {
    clearProof();
    addHeader("PREREQUISITE CHAIN VERIFICATION PROOF");
    
    addProofStep("Given course sequence:");
    std::string sequence = "";
    for (int i = 0; i < size; i++) {
        sequence += "CS" + std::to_string(courses[i]);
        if (i < size - 1) sequence += " → ";
    }
    addProofStep("Sequence: " + sequence);
    
    addProofStep("");
    addProofStep("PROOF STEPS:");
    addProofStep("1. Check if sequence maintains prerequisite order");
    
    bool isValid = true;
    for (int i = 1; i < size; i++) {
        std::string step = "   Course CS" + std::to_string(courses[i]) + 
                          " requires CS" + std::to_string(courses[i-1]);
        if (courses[i] > courses[i-1]) {
            step += " ✓ (SATISFIED)";
        } else {
            step += " ✗ (VIOLATION)";
            isValid = false;
        }
        addProofStep(step);
    }
    
    addProofStep("");
    addProofStep("2. Apply strong induction principle:");
    addProofStep("   Base case: First course has no prerequisites ✓");
    addProofStep("   Inductive step: Each course depends only on previous courses");
    
    addConclusion(isValid);
}

void ProofEngine::verifyLogicRule(const std::string& rule) {
    clearProof();
    addHeader("LOGIC RULE VERIFICATION PROOF");
    
    addProofStep("Given rule: " + rule);
    addProofStep("");
    addProofStep("PROOF STEPS:");
    addProofStep("1. Parse rule into propositional logic form");
    addProofStep("2. Check for logical consistency");
    addProofStep("3. Verify no contradictions in knowledge base");
    addProofStep("4. Ensure rule follows inference rules");
    
    addConclusion(true);
}

void ProofEngine::displayProof() {
    std::cout << "\nFORMAL PROOF:" << std::endl;
    std::cout << "=============" << std::endl;
    for (int i = 0; i < stepCount; i++) {
        std::cout << proofSteps[i] << std::endl;
    }
    std::cout << "=============" << std::endl;
}

void ProofEngine::clearProof() {
    stepCount = 0;
}