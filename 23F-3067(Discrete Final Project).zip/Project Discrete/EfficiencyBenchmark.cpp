#include "EfficiencyBenchmark.h"
#include <iostream>
#include <cmath>

EfficiencyBenchmark::EfficiencyBenchmark() {
    combinationTime = 0.0;
    schedulingTime = 0.0;
    setOperationTime = 0.0;
}

void EfficiencyBenchmark::startTimer() {
    startTime = clock();
}

void EfficiencyBenchmark::stopTimer() {
    endTime = clock();
}

double EfficiencyBenchmark::getElapsedTime() {
    return double(endTime - startTime) / CLOCKS_PER_SEC;
}

void EfficiencyBenchmark::benchmarkCombinations(int n, int r) {
    std::cout << "\nBenchmarking combinations C(" << n << "," << r << ")..." << std::endl;
    startTimer();
    
    // Simulate combination calculation
    long long result = 1;
    for (int i = 1; i <= r; i++) {
        result = result * (n - i + 1) / i;
    }
    
    stopTimer();
    combinationTime = getElapsedTime();
    std::cout << "Combinations: " << result << " | Time: " << combinationTime << "s" << std::endl;
}

void EfficiencyBenchmark::benchmarkScheduleGeneration(int courseCount) {
    std::cout << "Benchmarking schedule generation for " << courseCount << " courses..." << std::endl;
    startTimer();
    
    long long possibleSchedules = 1;
    for (int i = 1; i <= courseCount; i++) {
        possibleSchedules *= i;
    }
    
    stopTimer();
    schedulingTime = getElapsedTime();
    std::cout << "Possible schedules: " << possibleSchedules << " | Time: " << schedulingTime << "s" << std::endl;
}

void EfficiencyBenchmark::benchmarkSetOperations(int setSize) {
    std::cout << "Benchmarking set operations for sets of size " << setSize << "..." << std::endl;
    startTimer();
    
    // Simulate set operations (O(n^2) complexity)
    int operations = 0;
    for (int i = 0; i < setSize; i++) {
        for (int j = 0; j < setSize; j++) {
            operations++;
        }
    }
    
    stopTimer();
    setOperationTime = getElapsedTime();
    std::cout << "Operations performed: " << operations << " | Time: " << setOperationTime << "s" << std::endl;
}

void EfficiencyBenchmark::displayBenchmarks() {
    std::cout << "\n=== ALGORITHMIC EFFICIENCY BENCHMARKS ===" << std::endl;
    std::cout << "Combination Calculations: " << combinationTime << " seconds" << std::endl;
    std::cout << "Schedule Generation: " << schedulingTime << " seconds" << std::endl;
    std::cout << "Set Operations: " << setOperationTime << " seconds" << std::endl;
    
    std::cout << "\nPERFORMANCE ANALYSIS:" << std::endl;
    if (combinationTime < 0.1) std::cout << "✓ Combinations: Efficient" << std::endl;
    else std::cout << "✗ Combinations: Needs optimization" << std::endl;
    
    if (schedulingTime < 1.0) std::cout << "✓ Scheduling: Efficient" << std::endl;
    else std::cout << "✗ Scheduling: Needs optimization" << std::endl;
    
    if (setOperationTime < 0.5) std::cout << "✓ Set Operations: Efficient" << std::endl;
    else std::cout << "✗ Set Operations: Needs optimization" << std::endl;
}