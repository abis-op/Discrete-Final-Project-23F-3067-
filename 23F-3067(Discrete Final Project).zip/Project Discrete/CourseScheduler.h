#ifndef COURSE_SCHEDULER_H
#define COURSE_SCHEDULER_H

#include <string>

class Course {
public:
    Course();
    Course(int courseId, std::string courseCode, std::string courseName);
    
    int getCourseId() const;
    std::string getCourseCode() const;
    std::string getCourseName() const;
    
private:
    int id;
    std::string code;
    std::string name;
};

class CourseScheduler {
public:
    CourseScheduler(int maxCourses);
    ~CourseScheduler();
    
    void addCourse(int courseId, std::string code, std::string name);
    void addPrerequisite(int prereqId, int courseId);
    
    bool checkForCycles();
    void generateValidSchedules();
    long long countPossibleSchedules();
    void displaySchedule(int schedule[], int size);
    
private:
    static const int MAX_COURSES = 20;
    int totalCourses;
    Course courses[MAX_COURSES];
    bool prerequisites[MAX_COURSES][MAX_COURSES];
    int inDegree[MAX_COURSES];
    bool courseExists[MAX_COURSES];
    
    bool depthFirstCycleCheck(int course, int visited[]);
    void generateScheduleRecursive(int currentSchedule[], int scheduleSize, 
                                  int currentInDegree[], bool used[]);
};

#endif