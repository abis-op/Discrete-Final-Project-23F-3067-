#pragma once
#include <string>

class SetOps {
public:
    static int findUnion(int A[], int sizeA, int B[], int sizeB, int result[]);

    static int setUnion(int A[], int sizeA, int B[], int sizeB, int result[]);
    static int findIntersection(int A[], int sizeA, int B[], int sizeB, int result[]);
    static int findDifference(int A[], int sizeA, int B[], int sizeB, int result[]);
    static void displaySet(int set[], int size, const std::string& name);
};
