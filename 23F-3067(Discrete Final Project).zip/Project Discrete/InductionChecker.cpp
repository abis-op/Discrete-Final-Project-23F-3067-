#include "InductionChecker.h"
#include <iostream>

bool InductionChecker::verifyStepByStep(int chain[], int length) 
{
    // Check each course in the chain
    for (int current = 1; current < length; current++) 
    {
        std::cout << "Checking course " << chain[current] 
                  << " against previous course " << chain[current - 1];
        
        // Each course must come after all previous ones
        if (chain[current] <= chain[current - 1]) {
            std::cout << " -> FAIL: Course sequence broken!" << std::endl;
            return false;
        }
        std::cout << " -> OK" << std::endl;
    }
    return true;
}

bool InductionChecker::checkPrerequisiteChain(int courseChain[], int chainLength) {
    std::cout << "\n=== Verifying Course Prerequisite Chain ===" << std::endl;
    std::cout << "Chain: ";
    for (int i = 0; i < chainLength; i++) {
        std::cout << "CS" << courseChain[i];
        if (i < chainLength - 1) {
            std::cout << " -> ";
        }
    }
    std::cout << std::endl;
    
    // Basic validation
    if (chainLength <= 0) 
    {
        std::cout << "Error: Empty chain" << std::endl;
        return false;
    }
    
    if (chainLength == 1) 
    {
        std::cout << "Single course - automatically valid" << std::endl;
        return true;
    }
    
    std::cout << "\nApplying strong induction verification:" << std::endl;
    std::cout << "----------------------------------------" << std::endl;
    
    bool isValid = verifyStepByStep(courseChain, chainLength);
    
    std::cout << "----------------------------------------" << std::endl;
    if (isValid) 
    {
        std::cout << "RESULT: Chain is VALID - all prerequisites satisfied!" << std::endl;
    }
    else
    {
        std::cout << "RESULT: Chain is INVALID - prerequisite violation!" << std::endl;
    }
    
    return isValid;
}