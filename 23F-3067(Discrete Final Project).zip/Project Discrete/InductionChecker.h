#ifndef INDUCTION_CHECKER_H
#define INDUCTION_CHECKER_H

class InductionChecker 
{
public:
    static bool checkPrerequisiteChain(int courseChain[], int chainLength);
    
private:
    static bool verifyStepByStep(int chain[], int length);
};

#endif