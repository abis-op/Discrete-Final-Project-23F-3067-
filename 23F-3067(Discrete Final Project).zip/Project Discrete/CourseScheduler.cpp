#include "CourseScheduler.h"
#include <iostream>
#include <string>


Course::Course() : id(-1), code(""), name("") {}

Course::Course(int courseId, std::string courseCode, std::string courseName) 
    : id(courseId), code(courseCode), name(courseName) {}

int Course::getCourseId() const { return id; }
std::string Course::getCourseCode() const { return code; }
std::string Course::getCourseName() const { return name; }

CourseScheduler::CourseScheduler(int maxCourses) {
    totalCourses = 0;
 
    for (int i = 0; i < MAX_COURSES; i++) {
        courseExists[i] = false;
        inDegree[i] = 0;
        for (int j = 0; j < MAX_COURSES; j++) {
            prerequisites[i][j] = false;
        }
    }
}

CourseScheduler::~CourseScheduler() {
}

void CourseScheduler::addCourse(int courseId, std::string code, std::string name) {
    if (courseId >= 0 && courseId < MAX_COURSES) {
        courses[courseId] = Course(courseId, code, name);
        courseExists[courseId] = true;
        totalCourses++;
        std::cout << "Added course: " << code << " (" << name << ")" << std::endl;
    }
}

void CourseScheduler::addPrerequisite(int prereqId, int courseId) {
    if (prereqId >= 0 && prereqId < MAX_COURSES && courseId >= 0 && courseId < MAX_COURSES) {
        prerequisites[prereqId][courseId] = true;
        inDegree[courseId]++;
        std::cout << "Added prerequisite: " << courses[prereqId].getCourseCode() 
                  << " -> " << courses[courseId].getCourseCode() << std::endl;
    }
}

bool CourseScheduler::depthFirstCycleCheck(int course, int visited[]) {
    visited[course] = 1; // Currently visiting
    
    for (int nextCourse = 0; nextCourse < MAX_COURSES; nextCourse++) {
        if (prerequisites[course][nextCourse] && courseExists[nextCourse]) {
            if (visited[nextCourse] == 1) {
                return true; // Found cycle
            }
            if (visited[nextCourse] == 0 && depthFirstCycleCheck(nextCourse, visited)) {
                return true;
            }
        }
    }
    
    visited[course] = 2; // Fully visited
    return false;
}

bool CourseScheduler::checkForCycles() {
    std::cout << "\nChecking for prerequisite cycles..." << std::endl;
    int visited[MAX_COURSES] = {0};
    
    for (int i = 0; i < MAX_COURSES; i++) {
        if (courseExists[i] && visited[i] == 0) {
            if (depthFirstCycleCheck(i, visited)) {
                std::cout << "ERROR: Cycle detected in prerequisites!" << std::endl;
                return true;
            }
        }
    }
    
    std::cout << "No cycles found - prerequisite chain is valid" << std::endl;
    return false;
}

void CourseScheduler::displaySchedule(int schedule[], int size) {
    std::cout << "Valid Schedule: ";
    for (int i = 0; i < size; i++) {
        std::cout << courses[schedule[i]].getCourseCode();
        if (i < size - 1) {
            std::cout << " -> ";
        }
    }
    std::cout << std::endl;
}

void CourseScheduler::generateScheduleRecursive(int currentSchedule[], int scheduleSize, 
                                               int currentInDegree[], bool used[]) {
    if (scheduleSize == totalCourses) {
        displaySchedule(currentSchedule, scheduleSize);
        return;
    }
    
    for (int course = 0; course < MAX_COURSES; course++) {
        if (courseExists[course] && !used[course] && currentInDegree[course] == 0) {
            // Take this course
            used[course] = true;
            currentSchedule[scheduleSize] = course;
            
            // Update in-degrees of dependent courses
            int modifiedCourses[MAX_COURSES];
            int modifiedCount = 0;
            
            for (int nextCourse = 0; nextCourse < MAX_COURSES; nextCourse++) {
                if (prerequisites[course][nextCourse]) {
                    currentInDegree[nextCourse]--;
                    modifiedCourses[modifiedCount] = nextCourse;
                    modifiedCount++;
                }
            }
            
            // Recursive call
            generateScheduleRecursive(currentSchedule, scheduleSize + 1, currentInDegree, used);
            
            // Backtrack - restore in-degrees
            for (int i = 0; i < modifiedCount; i++) {
                currentInDegree[modifiedCourses[i]]++;
            }
            
            used[course] = false;
        }
    }
}

void CourseScheduler::generateValidSchedules() {
    std::cout << "\n=== Generating Valid Course Schedules ===" << std::endl;
    
    if (checkForCycles()) {
        std::cout << "Cannot generate schedules - prerequisite cycle exists!" << std::endl;
        return;
    }
    
    int currentSchedule[MAX_COURSES];
    int currentInDegree[MAX_COURSES];
    bool used[MAX_COURSES] = {false};
    
    // Copy in-degree array
    for (int i = 0; i < MAX_COURSES; i++) {
        currentInDegree[i] = inDegree[i];
    }
    
    std::cout << "\nValid course sequences:" << std::endl;
    std::cout << "-----------------------" << std::endl;
    generateScheduleRecursive(currentSchedule, 0, currentInDegree, used);
}

long long CourseScheduler::countPossibleSchedules() {
    std::cout << "\nCounting total possible schedules..." << std::endl;
    
    if (checkForCycles()) {
        return 0;
    }
    
    // Simple approach for small cases
    if (totalCourses > 8) {
        std::cout << "Too many courses for exact count (>" << totalCourses << " courses)" << std::endl;
        return -1;
    }
   
    int count = 0;
    int currentSchedule[MAX_COURSES];
    int currentInDegree[MAX_COURSES];
    bool used[MAX_COURSES] = {false};
    
    for (int i = 0; i < MAX_COURSES; i++) {
        currentInDegree[i] = inDegree[i];
    }
    
    std::cout << "Schedule counting requires dynamic programming implementation" << std::endl;
    std::cout << "For " << totalCourses << " courses, many valid schedules exist" << std::endl;
    
    return -1; // Indicates counting not implemented for simplicity
}