#include "Relation.h"
#include <iostream>

Relation::Relation(int pairs[][2], int pairCount) {
    totalPairs = pairCount;
    for (int i = 0; i < pairCount; i++) {
        relationPairs[i][0] = pairs[i][0];
        relationPairs[i][1] = pairs[i][1];
    }
}

void Relation::displayRelation() {
    std::cout << "Relation R = {";
    for (int i = 0; i < totalPairs; i++) {
        std::cout << "(" << relationPairs[i][0] << "," << relationPairs[i][1] << ")";
        if (i < totalPairs - 1) {
            std::cout << ", ";
        }
    }
    std::cout << "}" << std::endl;
}

bool Relation::containsPair(int x, int y) {
    for (int i = 0; i < totalPairs; i++) {
        if (relationPairs[i][0] == x && relationPairs[i][1] == y) {
            return true;
        }
    }
    return false;
}

bool Relation::checkReflexive(int domainSize) {
    std::cout << "\nChecking Reflexive Property:" << std::endl;
    std::cout << "Every element must relate to itself" << std::endl;
    
    for (int element = 1; element <= domainSize; element++) {
        bool hasSelfPair = containsPair(element, element);
        std::cout << "  Element " << element << " has ("
                  << element << "," << element << "): " 
                  << (hasSelfPair ? "YES" : "NO") << std::endl;
        
        if (!hasSelfPair) {
            std::cout << "  FAIL: Element " << element 
                      << " is not related to itself!" << std::endl;
            return false;
        }
    }
    std::cout << "  SUCCESS: Relation is reflexive" << std::endl;
    return true;
}

bool Relation::checkSymmetric() {
    std::cout << "\nChecking Symmetric Property:" << std::endl;
    std::cout << "If (a,b) is in R, then (b,a) must also be in R" << std::endl;
    
    for (int i = 0; i < totalPairs; i++) {
        int a = relationPairs[i][0];
        int b = relationPairs[i][1];
        
        // Skip self-pairs for symmetry check
        if (a == b) continue;
        
        bool hasReverse = containsPair(b, a);
        std::cout << "  Pair (" << a << "," << b << ") has reverse (" 
                  << b << "," << a << "): " 
                  << (hasReverse ? "YES" : "NO") << std::endl;
        
        if (!hasReverse) {
            std::cout << "  FAIL: Reverse pair (" << b << "," << a 
                      << ") is missing!" << std::endl;
            return false;
        }
    }
    std::cout << "  SUCCESS: Relation is symmetric" << std::endl;
    return true;
}

bool Relation::checkTransitive() {
    std::cout << "\nChecking Transitive Property:" << std::endl;
    std::cout << "If (a,b) and (b,c) are in R, then (a,c) must be in R" << std::endl;
    
    for (int i = 0; i < totalPairs; i++) {
        int a = relationPairs[i][0];
        int b = relationPairs[i][1];
        
        for (int j = 0; j < totalPairs; j++) {
            if (relationPairs[j][0] == b) {
                int c = relationPairs[j][1];
                
                // We have (a,b) and (b,c), check for (a,c)
                if (!containsPair(a, c)) {
                    std::cout << "  FAIL: Found (" << a << "," << b 
                              << ") and (" << b << "," << c 
                              << ") but missing (" << a << "," << c << ")" << std::endl;
                    return false;
                } else {
                    std::cout << "  Valid: (" << a << "," << b << "), (" 
                              << b << "," << c << ") -> (" << a << "," << c << ")" << std::endl;
                }
            }
        }
    }
    std::cout << "  SUCCESS: Relation is transitive" << std::endl;
    return true;
}

bool Relation::isEquivalenceRelation(int domainSize) {
    std::cout << "\n=== Checking Equivalence Relation ===" << std::endl;
    bool reflexive = checkReflexive(domainSize);
    bool symmetric = checkSymmetric();
    bool transitive = checkTransitive();
    
    std::cout << "\nFINAL RESULT: ";
    if (reflexive && symmetric && transitive) {
        std::cout << "Relation is an EQUIVALENCE RELATION" << std::endl;
        return true;
    } else {
        std::cout << "Relation is NOT an equivalence relation" << std::endl;
        return false;
    }
}

bool Relation::isPartialOrder(int domainSize) {
    std::cout << "\n=== Checking Partial Order ===" << std::endl;
    bool reflexive = checkReflexive(domainSize);
    
    bool transitive = checkTransitive();
    
    std::cout << "\nFINAL RESULT: ";
    if (reflexive && transitive) {
        std::cout << "Relation is a PARTIAL ORDER" << std::endl;
        return true;
    } else {
        std::cout << "Relation is NOT a partial order" << std::endl;
        return false;
    }
}