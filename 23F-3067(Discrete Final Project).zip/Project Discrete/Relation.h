#ifndef RELATION_H
#define RELATION_H

class Relation {
public:
    Relation(int pairs[][2], int pairCount);
    void displayRelation();
    bool checkReflexive(int domainSize);
    bool checkSymmetric();
    bool checkTransitive();
    bool isEquivalenceRelation(int domainSize);
    bool isPartialOrder(int domainSize);

private:
    static const int MAX_PAIRS = 50;
    int relationPairs[MAX_PAIRS][2];
    int totalPairs;
    bool containsPair(int x, int y);
};

#endif