#include "FunctionMap.h"
#include <iostream>

FunctionMap::FunctionMap() {
    mappingCount = 0;
}

void FunctionMap::addMapping(int input, int output) {
    if (mappingCount < MAX_MAPPINGS) {
        inputs[mappingCount] = input;
        outputs[mappingCount] = output;
        mappingCount++;
        std::cout << "Added mapping: " << input << " -> " << output << std::endl;
    } else {
        std::cout << "Cannot add more mappings - maximum limit reached!" << std::endl;
    }
}

void FunctionMap::displayFunction() {
    std::cout << "Function f = {";
    for (int i = 0; i < mappingCount; i++) {
        std::cout << "(" << inputs[i] << "→" << outputs[i] << ")";
        if (i < mappingCount - 1) {
            std::cout << ", ";
        }
    }
    std::cout << "}" << std::endl;
}

bool FunctionMap::outputValueExists(int value) {
    for (int i = 0; i < mappingCount; i++) {
        if (outputs[i] == value) {
            return true;
        }
    }
    return false;
}

bool FunctionMap::checkInjective() {
    std::cout << "\nChecking Injective (One-to-One) Property:" << std::endl;
    std::cout << "Each output must come from exactly one input" << std::endl;
    
    for (int i = 0; i < mappingCount; i++) {
        for (int j = i + 1; j < mappingCount; j++) {
            if (outputs[i] == outputs[j]) {
                std::cout << "  FAIL: Output " << outputs[i] 
                          << " has multiple inputs (" << inputs[i] 
                          << " and " << inputs[j] << ")" << std::endl;
                return false;
            }
        }
    }
    
    std::cout << "  SUCCESS: Function is injective (one-to-one)" << std::endl;
    return true;
}

bool FunctionMap::checkSurjective(int codomainSize) {
    std::cout << "\nChecking Surjective (Onto) Property:" << std::endl;
    std::cout << "All elements in codomain must be covered" << std::endl;
    
    for (int codomainElement = 1; codomainElement <= codomainSize; codomainElement++) {
        bool found = outputValueExists(codomainElement);
        std::cout << "  Codomain element " << codomainElement 
                  << " is mapped: " << (found ? "YES" : "NO") << std::endl;
        
        if (!found) {
            std::cout << "  FAIL: Codomain element " << codomainElement 
                      << " is not mapped by any input!" << std::endl;
            return false;
        }
    }
    
    std::cout << "  SUCCESS: Function is surjective (onto)" << std::endl;
    return true;
}

bool FunctionMap::checkBijective(int codomainSize) {
    std::cout << "\n=== Checking Bijective Property ===" << std::endl;
    std::cout << "Function must be both injective and surjective" << std::endl;
    
    bool injective = checkInjective();
    bool surjective = checkSurjective(codomainSize);
    
    std::cout << "\nFINAL RESULT: ";
    if (injective && surjective) {
        std::cout << "Function is BIJECTIVE (one-to-one and onto)" << std::endl;
        return true;
    } else {
        std::cout << "Function is NOT bijective" << std::endl;
        return false;
    }
}