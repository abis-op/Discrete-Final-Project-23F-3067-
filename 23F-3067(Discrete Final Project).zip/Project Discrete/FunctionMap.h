#ifndef FUNCTION_MAP_H
#define FUNCTION_MAP_H

class FunctionMap {
public:
    FunctionMap();
    void addMapping(int input, int output);
    void displayFunction();
    bool checkInjective();
    bool checkSurjective(int codomainSize);
    bool checkBijective(int codomainSize);
    
private:
    static const int MAX_MAPPINGS = 50;
    int inputs[MAX_MAPPINGS];
    int outputs[MAX_MAPPINGS];
    int mappingCount;
    bool outputValueExists(int value);
};

#endif