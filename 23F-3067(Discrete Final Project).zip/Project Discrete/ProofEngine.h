#ifndef PROOF_ENGINE_H
#define PROOF_ENGINE_H

#include <string>

class ProofEngine {
public:
    ProofEngine();
    void addProofStep(const std::string& step);
    void verifyPrerequisiteChain(int courses[], int size);
    void verifyLogicRule(const std::string& rule);
    void displayProof();
    void clearProof();

private:
    static const int MAX_STEPS = 100;
    std::string proofSteps[MAX_STEPS];
    int stepCount;
    
    void addHeader(const std::string& title);
    void addConclusion(bool isValid);
};

#endif