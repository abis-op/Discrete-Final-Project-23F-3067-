#include "Combinator.h"
#include <iostream>

const int MAX_GROUPS = 1000;
const int MAX_GROUP_SIZE = 10;
int allGroups[MAX_GROUPS][MAX_GROUP_SIZE];
int groupCount = 0;

void Combinator::displayGroup(int* group, int size) 
{
    std::cout << "Group " << (groupCount + 1) << ": ";
    for (int i = 0; i < size; i++) {
        std::cout << "S" << group[i];
        if (i < size - 1) {
            std::cout << " ";
        }
    }
    std::cout << std::endl;
}

void Combinator::buildGroups(int start, int total, int needed, 
                            int* currentGroup, int currentSize) {
    
    // If we have enough students in current group
    if (currentSize == needed) {
        // Save this group
        for (int i = 0; i < currentSize; i++) {
            allGroups[groupCount][i] = currentGroup[i];
        }
        displayGroup(currentGroup, currentSize);
        groupCount++;
        return;
    }
    
    
    if (total - start + 1 < needed - currentSize) {
        return;
    }
    
    // Try adding each remaining student
    for (int studentId = start; studentId <= total; studentId++) {
        currentGroup[currentSize] = studentId;
        buildGroups(studentId + 1, total, needed, currentGroup, currentSize + 1);
    }
}

void Combinator::createStudentGroups(int totalStudents, int groupSize) {
    // Reset global counter
    groupCount = 0;
    
    // Basic validation
    if (groupSize > totalStudents || groupSize <= 0) {
        std::cout << "Error: Cannot make groups of " << groupSize 
                  << " from " << totalStudents << " students" << std::endl;
        return;
    }
    
    if (groupSize > MAX_GROUP_SIZE) {
        std::cout << "Error: Group size too large" << std::endl;
        return;
    }
    
    std::cout << "\nCreating all possible groups of " << groupSize 
              << " students from " << totalStudents << " total students:" << std::endl;
    std::cout << "==============================================" << std::endl;
    
    int currentGroup[MAX_GROUP_SIZE];
    buildGroups(1, totalStudents, groupSize, currentGroup, 0);
    
    std::cout << "==============================================" << std::endl;
    std::cout << "Total groups created: " << groupCount << std::endl;
}