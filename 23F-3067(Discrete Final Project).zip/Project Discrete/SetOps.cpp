#include "SetOps.h"
#include <iostream>
#include <string>

// Union of two sets
int SetOps::setUnion(int A[], int sizeA, int B[], int sizeB, int result[]) {
    int k = 0;

    // Copy all elements of A
    for (int i = 0; i < sizeA; i++)
        result[k++] = A[i];

    // Add elements of B not in A
    for (int i = 0; i < sizeB; i++) {
        bool found = false;
        for (int j = 0; j < sizeA; j++) {
            if (B[i] == A[j]) {
                found = true;
                break;
            }
        }
        if (!found)
            result[k++] = B[i];
    }

    return k; // return size of union
}
int SetOps::findUnion(int A[], int sizeA, int B[], int sizeB, int result[]) {
    int k = 0;

    for (int i = 0; i < sizeA; i++)
        result[k++] = A[i];

    for (int i = 0; i < sizeB; i++) {
        bool found = false;
        for (int j = 0; j < sizeA; j++) {
            if (B[i] == A[j]) {
                found = true;
                break;
            }
        }
        if (!found)
            result[k++] = B[i];
    }

    return k;
}

// Intersection of two sets
int SetOps::findIntersection(int A[], int sizeA, int B[], int sizeB, int result[]) {
    int k = 0;
    for (int i = 0; i < sizeA; i++) {
        for (int j = 0; j < sizeB; j++) {
            if (A[i] == B[j]) {
                result[k++] = A[i];
                break;
            }
        }
    }
    return k; // return size of intersection
}

// Difference A - B
int SetOps::findDifference(int A[], int sizeA, int B[], int sizeB, int result[]) {
    int k = 0;
    for (int i = 0; i < sizeA; i++) {
        bool found = false;
        for (int j = 0; j < sizeB; j++) {
            if (A[i] == B[j]) {
                found = true;
                break;
            }
        }
        if (!found)
            result[k++] = A[i];
    }
    return k; // return size of difference
}

// Display a set
void SetOps::displaySet(int set[], int size, const std::string& name) {
    std::cout << name << ": { ";
    for (int i = 0; i < size; i++) {
        std::cout << set[i];
        if (i != size - 1) std::cout << ", ";
    }
    std::cout << " }" << std::endl;
}
