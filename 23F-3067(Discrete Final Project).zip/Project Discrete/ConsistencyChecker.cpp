#include "ConsistencyChecker.h"

ConsistencyChecker::ConsistencyChecker() {
    violationCount = 0;
}

void ConsistencyChecker::addViolation(const std::string& violation) {
    if (violationCount < MAX_VIOLATIONS) {
        violations[violationCount++] = violation;
    }
}

void ConsistencyChecker::checkCourseOverlap(int schedule[][10], int numCourses) {
    for (int i = 0; i < numCourses; i++) {
        for (int j = i + 1; j < numCourses; j++) {
            for (int t = 0; t < 10; t++) {
                if (schedule[i][t] == 1 && schedule[j][t] == 1) {
                    addViolation("Course " + std::to_string(i) +
                                 " overlaps with course " + std::to_string(j));
                }
            }
        }
    }
}

void ConsistencyChecker::checkPrerequisiteViolation(int prereq[][2], int prereqCount, int completed[], int completedCount) {
    for (int i = 0; i < prereqCount; i++) {
        bool found = false;
        for (int j = 0; j < completedCount; j++) {
            if (completed[j] == prereq[i][0]) {
                found = true;
                break;
            }
        }
        if (!found) {
            addViolation("Prerequisite " + std::to_string(prereq[i][0]) +
                         " missing for course " + std::to_string(prereq[i][1]));
        }
    }
}

void ConsistencyChecker::checkFacultyOverload(int facultyCourses[][10], int facultyCount) {
    for (int i = 0; i < facultyCount; i++) {
        int load = 0;
        for (int j = 0; j < 10; j++) {
            load += facultyCourses[i][j];
        }
        if (load > 5) {
            addViolation("Faculty " + std::to_string(i) +
                         " teaching overload (" + std::to_string(load) + " courses)");
        }
    }
}

void ConsistencyChecker::checkRoomConflicts(int rooms[][24], int roomCount) {
    for (int i = 0; i < roomCount; i++) {
        for (int j = i + 1; j < roomCount; j++) {
            for (int t = 0; t < 24; t++) {
                if (rooms[i][t] == 1 && rooms[j][t] == 1) {
                    addViolation("Room " + std::to_string(i) +
                                 " conflicts with room " + std::to_string(j) +
                                 " at hour " + std::to_string(t));
                }
            }
        }
    }
}

void ConsistencyChecker::displayViolations() {
    if (violationCount == 0) {
        std::cout << "No consistency violations found.\n";
        return;
    }

    std::cout << "\n=== Consistency Violations ===\n";
    for (int i = 0; i < violationCount; i++) {
        std::cout << i+1 << ". " << violations[i] << "\n";
    }
}
