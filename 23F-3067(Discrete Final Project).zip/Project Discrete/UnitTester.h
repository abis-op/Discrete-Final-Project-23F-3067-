#ifndef UNIT_TESTER_H
#define UNIT_TESTER_H

#include <string>
#include <iostream>

class UnitTester {
private:
    int testsPassed;
    int testsFailed;

public:
    UnitTester();

    void assertTrue(bool condition, const std::string& testName);
    void assertFalse(bool condition, const std::string& testName);

    void testCombinations();
    void testInduction();
    void testLogic();
    void testSets();
    void testRelations();
    void testFunctions();
    void testScheduling();

    void runAllTests();
};

#endif
