#include <iostream>
#include <string>
#include <limits>

#include "Combinator.h"
#include "InductionChecker.h"
#include "LogicEngine.h"
#include "Relation.h"
#include "FunctionMap.h"
#include "CourseScheduler.h"
#include "ProofEngine.h"
#include "ConsistencyChecker.h"
#include "EfficiencyBenchmark.h"
#include "CLIInterface.h"
#include "UnitTester.h"

using namespace std;

void displayWelcome() {
    cout << "==================================================" << endl;
    cout << "    FAST University - Discrete Structures Project" << endl;
    cout << "         Academic Management System" << endl;
    cout << "==================================================" << endl;
    cout << "Modules Integrated:" << endl;
    cout << "1. Student Group Combinations" << endl;
    cout << "2. Course Prerequisite Induction" << endl;
    cout << "3. Logic Rule Inference Engine" << endl;
    cout << "4. Relation Properties Checking" << endl;
    cout << "5. Function Properties Verification" << endl;
    cout << "6. Course Scheduling with Prerequisites" << endl;
    cout << "7. Integrated Scenario (All Modules Combined)" << endl;
    cout << "8. CLI Interface (interactive)" << endl;
    cout << "9. Automated Proof & Verification (ProofEngine)" << endl;
    cout << "10. Consistency Checker" << endl;
    cout << "11. Efficiency Benchmarking" << endl;
    cout << "12. Unit Tests" << endl;
    cout << "0. Exit" << endl;
    cout << "==================================================" << endl << endl;
}

void runGroupCombinationDemo() {
    cout << "\nMODULE 1: STUDENT GROUP COMBINATIONS" << endl;
    cout << "====================================" << endl;
    cout << "Creating lab groups of 2 students from 4 students:" << endl;
    Combinator::createStudentGroups(4, 2);
    cout << "\nCreating project groups of 3 students from 5 students:" << endl;
    Combinator::createStudentGroups(5, 3);
}

void runInductionDemo() {
    cout << "\nMODULE 2: COURSE PREREQUISITE INDUCTION" << endl;
    cout << "=====================================" << endl;
    int validChain[] = {101, 201, 301, 401};
    cout << "Valid CS Course Sequence:" << endl;
    InductionChecker::checkPrerequisiteChain(validChain, 4);
    int invalidChain[] = {301, 101, 201};
    cout << "\nInvalid Course Sequence:" << endl;
    InductionChecker::checkPrerequisiteChain(invalidChain, 3);
}

void runLogicEngineDemo() {
    cout << "\nMODULE 3: LOGIC INFERENCE ENGINE" << endl;
    cout << "===============================" << endl;
    LogicEngine engine;
    cout << "Adding university rules..." << endl;
    engine.addRule("pass_CS101", "can_take_CS201");
    engine.addRule("pass_CS201", "can_take_CS301");
    engine.addRule("pass_CS301", "can_take_CS401");
    engine.addRule("pass_MATH101", "can_take_CS201");
    engine.addRule("prof_X_teaching", "use_lab_A");
    engine.displayAllRules();
    cout << "\nTesting inferences:" << endl;
    engine.checkRule("pass_CS101", "can_take_CS301");
    engine.checkRule("pass_MATH101", "can_take_CS401");
    engine.checkRule("prof_X_teaching", "use_lab_A");
}

void runRelationDemo() {
    cout << "\nMODULE 4: RELATION PROPERTIES" << endl;
    cout << "============================" << endl;
    int equivPairs[][2] = {
        {1,1}, {2,2}, {3,3}, {4,4},
        {1,2}, {2,1}, {3,4}, {4,3},
        {1,1}, {2,2}, {3,3}, {4,4}
    };
    Relation equivRel(equivPairs, 12);
    equivRel.displayRelation();
    equivRel.isEquivalenceRelation(4);
    int prereqPairs[][2] = {
        {101,101}, {201,201}, {301,301},
        {101,201}, {101,301}, {201,301}
    };
    Relation prereqRel(prereqPairs, 6);
    prereqRel.displayRelation();
    prereqRel.isPartialOrder(3);
}

void runFunctionDemo() {
    cout << "\nMODULE 5: FUNCTION PROPERTIES" << endl;
    cout << "============================" << endl;
    FunctionMap injectiveFunc;
    cout << "Student to ID mapping (Injective):" << endl;
    injectiveFunc.addMapping(1001, 5001);
    injectiveFunc.addMapping(1002, 5002);
    injectiveFunc.addMapping(1003, 5003);
    injectiveFunc.displayFunction();
    injectiveFunc.checkInjective();
    FunctionMap surjectiveFunc;
    cout << "\nCourse to Faculty mapping (Surjective):" << endl;
    surjectiveFunc.addMapping(101, 201);
    surjectiveFunc.addMapping(102, 202);
    surjectiveFunc.addMapping(103, 201);
    surjectiveFunc.addMapping(104, 203);
    surjectiveFunc.displayFunction();
    surjectiveFunc.checkSurjective(3);
    FunctionMap bijectiveFunc;
    cout << "\nRoom to Course mapping (Bijective):" << endl;
    bijectiveFunc.addMapping(301, 101);
    bijectiveFunc.addMapping(302, 102);
    bijectiveFunc.addMapping(303, 103);
    bijectiveFunc.displayFunction();
    bijectiveFunc.checkBijective(3);
}

void runSchedulingDemo() {
    cout << "\nMODULE 6: COURSE SCHEDULING" << endl;
    cout << "===========================" << endl;
    CourseScheduler scheduler(6);
    cout << "Creating Computer Science Curriculum..." << endl;
    scheduler.addCourse(0, "CS101", "Introduction to Programming");
    scheduler.addCourse(1, "CS201", "Data Structures");
    scheduler.addCourse(2, "CS301", "Algorithms");
    scheduler.addCourse(3, "MATH101", "Calculus I");
    scheduler.addCourse(4, "MATH201", "Discrete Mathematics");
    scheduler.addCourse(5, "CS401", "Advanced Programming");
    cout << "\nDefining prerequisite structure..." << endl;
    scheduler.addPrerequisite(0, 1);
    scheduler.addPrerequisite(1, 2);
    scheduler.addPrerequisite(2, 5);
    scheduler.addPrerequisite(3, 4);
    cout << "\nGenerating valid course sequences..." << endl;
    scheduler.generateValidSchedules();
}

void runIntegratedScenario() {
    cout << "\nINTEGRATED SCENARIO: COMPLETE STUDENT MANAGEMENT" << endl;
    cout << "===============================================" << endl;
    cout << "1. Creating student groups for labs..." << endl;
    Combinator::createStudentGroups(6, 3);
    cout << "\n2. Verifying course prerequisite chains..." << endl;
    int courseChain[] = {101, 201, 301};
    InductionChecker::checkPrerequisiteChain(courseChain, 3);
    cout << "\n3. Checking enrollment rules..." << endl;
    LogicEngine logic;
    logic.addRule("completed_CS201", "eligible_CS301");
    logic.addRule("completed_MATH101", "eligible_CS201");
    logic.checkRule("completed_MATH101", "eligible_CS301");
    cout << "\n4. Final schedule generation..." << endl;
    CourseScheduler finalScheduler(4);
    finalScheduler.addCourse(0, "CS101", "Intro Programming");
    finalScheduler.addCourse(1, "CS201", "Data Structures");
    finalScheduler.addCourse(2, "MATH101", "Calculus");
    finalScheduler.addCourse(3, "CS301", "Algorithms");
    finalScheduler.addPrerequisite(0, 1);
    finalScheduler.addPrerequisite(1, 3);
    finalScheduler.generateValidSchedules();
}

void runProofDemo() {
    cout << "\n=== PROOF ENGINE DEMO ===" << endl;
    ProofEngine proof;
    int chain[] = {101, 201, 301};
    proof.verifyPrerequisiteChain(chain, 3);
    proof.displayProof();

    cout << "\nLogic rule demonstration (example):" << endl;
    proof.verifyLogicRule("IF pass_CS101 THEN can_take_CS201");
    proof.displayProof();
}

void runConsistencyDemo() {
    cout << "\n=== CONSISTENCY CHECKER DEMO ===" << endl;
    ConsistencyChecker checker;

    int studentCourses[3][10] = {
        {101, 102, 103, 104, 105, 106, 0, 0, 0, 0}, 
        {101, 102, 0, 0, 0, 0, 0, 0, 0, 0},
        {201, 202, 203, 0, 0, 0, 0, 0, 0, 0}
    };

    int prerequisites[][2] = {{101, 201}, {102, 202}}; 
    int enrolled[] = {201, 202};

    int facultyAssignments[2][10] = {
        {101, 102, 103, 104, 0,0,0,0,0,0}, 
        {201, 202, 0,0,0,0,0,0,0,0}
    };

    int roomSchedules[2][24] = {0};
    roomSchedules[0][2] = 2;

    checker.checkCourseOverlap(studentCourses, 3);
    checker.checkPrerequisiteViolation(prerequisites, 2, enrolled, 2);
    checker.checkFacultyOverload(facultyAssignments, 2);
    checker.checkRoomConflicts(roomSchedules, 2);
    checker.displayViolations();
}

void runBenchmarkDemo() {
    cout << "\n=== EFFICIENCY BENCHMARK DEMO ===" << endl;
    EfficiencyBenchmark bench;
    bench.benchmarkCombinations(15, 5);
    bench.benchmarkScheduleGeneration(6);
    bench.displayBenchmarks();
}

void runCLIInterface() {
    cout << "\n=== STARTING CLI INTERFACE ===" << endl;
    CLIInterface cli;
    cli.run();
}

void runUnitTests() {
    cout << "\n=== RUNNING UNIT TESTS ===" << endl;
    UnitTester tester;
    tester.runAllTests();
}

// ----- MAIN MENU -----
int main() {
    displayWelcome();

    int choice;
    do {
        cout << "\nSelect an option from the menu (0 to exit): ";
        if (!(cin >> choice)) {
            cout << "Invalid input. Try again." << endl;
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            continue;
        }

        switch (choice) {
            case 1: runGroupCombinationDemo(); break;
            case 2: runInductionDemo(); break;
            case 3: runLogicEngineDemo(); break;
            case 4: runRelationDemo(); break;
            case 5: runFunctionDemo(); break;
            case 6: runSchedulingDemo(); break;
            case 7: runIntegratedScenario(); break;
            case 8: runCLIInterface(); break;
            case 9: runProofDemo(); break;
            case 10: runConsistencyDemo(); break;
            case 11: runBenchmarkDemo(); break;
            case 12: runUnitTests(); break;
            case 0: cout << "Thank you for using FAST University System!" << endl; break;
            default: cout << "Invalid choice! Please try again." << endl;
        }

        if (choice != 0) {
            cout << "\nPress Enter to continue...";
            cin.ignore(numeric_limits<streamsize>::max(), '\n'); 
            cin.get();
        }

    } while (choice != 0);
    system("pause");
    return 0;
}
