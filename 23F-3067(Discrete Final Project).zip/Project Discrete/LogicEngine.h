#ifndef LOGIC_ENGINE_H
#define LOGIC_ENGINE_H

#include <string>

class LogicEngine 
{
public:
    LogicEngine();
    void addRule(std::string ifPart, std::string thenPart);
    bool checkRule(std::string startFact, std::string targetFact);
    void displayAllRules();
    
private:
    bool searchForFact(std::string current, std::string target);
    
    static const int MAX_RULES = 50;
    std::string ifParts[MAX_RULES];
    std::string thenParts[MAX_RULES];
    int ruleCount;
};

#endif