#ifndef EFFICIENCY_BENCHMARK_H
#define EFFICIENCY_BENCHMARK_H

#include <ctime>

class EfficiencyBenchmark {
public:
    EfficiencyBenchmark();
    void startTimer();
    void stopTimer();
    double getElapsedTime();
    
    void benchmarkCombinations(int n, int r);
    void benchmarkScheduleGeneration(int courseCount);
    void benchmarkSetOperations(int setSize);
    void displayBenchmarks();

private:
    clock_t startTime;
    clock_t endTime;
    double combinationTime;
    double schedulingTime;
    double setOperationTime;
};

#endif