#include "CLIInterface.h"
#include <iostream>
#include "Combinator.h"
#include "InductionChecker.h"
#include "LogicEngine.h"
#include "Relation.h"
#include "FunctionMap.h"
#include "CourseScheduler.h"
#include "ProofEngine.h"
#include "ConsistencyChecker.h"
#include "EfficiencyBenchmark.h"

using namespace std;

void CLIInterface::displayHeader() {
    cout << "==================================================" << endl;
    cout << "    FAST University - Discrete Structures Project" << endl;
    cout << "         Academic Management System v2.0" << endl;
    cout << "==================================================" << endl;
}

void CLIInterface::displayMainMenu() {
    cout << "\nMAIN MENU:" << endl;
    cout << "1. Run Complete System Demo" << endl;
    cout << "2. Individual Module Testing" << endl;
    cout << "3. Algorithm Efficiency Benchmark" << endl;
    cout << "4. System Consistency Check" << endl;
    cout << "5. Formal Proof Verification" << endl;
    cout << "0. Exit" << endl;
    cout << "Enter your choice: ";
}

void CLIInterface::displayModuleMenu() {
    cout << "\nMODULE SELECTION:" << endl;
    cout << "1. Student Group Combinations" << endl;
    cout << "2. Course Prerequisite Induction" << endl;
    cout << "3. Logic Inference Engine" << endl;
    cout << "4. Set Operations" << endl;
    cout << "5. Relation Properties" << endl;
    cout << "6. Function Properties" << endl;
    cout << "7. Course Scheduling" << endl;
    cout << "8. Back to Main Menu" << endl;
    cout << "Enter your choice: ";
}

int CLIInterface::getUserChoice() {
    int choice;
    cin >> choice;
    return choice;
}

void CLIInterface::handleMenuChoice(int choice) {
    switch(choice) {
        case 1: {
            cout << "\n=== RUNNING COMPLETE SYSTEM DEMO ===" << endl;
            
            // Group Combinations
            cout << "\n1. Student Group Combinations:" << endl;
            Combinator::createStudentGroups(4, 2);
            
            // Induction Checker
            cout << "\n2. Prerequisite Induction:" << endl;
            int chain[] = {101, 201, 301};
            InductionChecker::checkPrerequisiteChain(chain, 3);
            
            // Logic Engine
            cout << "\n3. Logic Inference:" << endl;
            LogicEngine logic;
            logic.addRule("pass_CS101", "can_take_CS201");
            logic.checkRule("pass_CS101", "can_take_CS201");
            
            // Set Operations
            cout << "\n4. Set Operations:" << endl;
            int setA[] = {1,2,3}, setB[] = {2,3,4};
            int result[10];
        
            
            break;
        }
        case 2: {
            int moduleChoice;
            do {
                displayModuleMenu();
                moduleChoice = getUserChoice();
                
                switch(moduleChoice) {
                    case 1:
                        Combinator::createStudentGroups(5, 2);
                        break;
                    case 2: {
                        int courses[] = {100, 200, 300};
                        InductionChecker::checkPrerequisiteChain(courses, 3);
                        break;
                    }
                    case 3: {
                        LogicEngine engine;
                        engine.addRule("A", "B");
                        engine.checkRule("A", "B");
                        break;
                    }
                    case 4: {
                        int set1[] = {1,2}, set2[] = {2,3};
                        int res[10];
                     
                        break;
                    }
                    case 8:
                        cout << "Returning to main menu..." << endl;
                        break;
                    default:
                        cout << "Module not implemented in this demo" << endl;
                }
            } while (moduleChoice != 8);
            break;
        }
        case 3: {
            cout << "\n=== ALGORITHM EFFICIENCY BENCHMARK ===" << endl;
            EfficiencyBenchmark benchmark;
            benchmark.benchmarkCombinations(10, 3);
            benchmark.benchmarkScheduleGeneration(5);
            benchmark.benchmarkSetOperations(100);
            benchmark.displayBenchmarks();
            break;
        }
        case 4: {
            cout << "\n=== SYSTEM CONSISTENCY CHECK ===" << endl;
            ConsistencyChecker checker;
            
            int studentCourses[3][10] = {
                {101, 102, 103, 104, 105, 106, 0, 0, 0, 0}, // Overloaded
                {101, 102, 0, 0, 0, 0, 0, 0, 0, 0},
                {201, 202, 203, 0, 0, 0, 0, 0, 0, 0}
            };
            
            int prerequisites[][2] = {{101, 201}, {102, 202}};
            int enrolled[] = {201, 202}; // Missing prerequisites
            
            checker.checkCourseOverlap(studentCourses, 3);
            checker.checkPrerequisiteViolation(prerequisites, 2, enrolled, 2);
            checker.displayViolations();
            break;
        }
        case 5: {
            cout << "\n=== FORMAL PROOF VERIFICATION ===" << endl;
            ProofEngine proof;
            int courses[] = {101, 201, 301};
            proof.verifyPrerequisiteChain(courses, 3);
            proof.displayProof();
            break;
        }
        case 0:
            cout << "Thank you for using FAST University System!" << endl;
            break;
        default:
            cout << "Invalid choice! Please try again." << endl;
    }
}

void CLIInterface::run() {
    int choice;
    do {
        displayHeader();
        displayMainMenu();
        choice = getUserChoice();
        handleMenuChoice(choice);
        
        if (choice != 0) {
            cout << "\nPress Enter to continue...";
            cin.ignore();
            cin.get();
        }
    } while (choice != 0);
}