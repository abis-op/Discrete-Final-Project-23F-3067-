#include "LogicEngine.h"
#include <iostream>
#include <string>

LogicEngine::LogicEngine() {
    ruleCount = 0;
}

void LogicEngine::addRule(std::string ifPart, std::string thenPart) {
    if (ruleCount < MAX_RULES) {
        ifParts[ruleCount] = ifPart;
        thenParts[ruleCount] = thenPart;
        ruleCount++;
        std::cout << "Added rule: IF " << ifPart << " THEN " << thenPart << std::endl;
    } else {
        std::cout << "Cannot add more rules - maximum limit reached!" << std::endl;
    }
}

void LogicEngine::displayAllRules() {
    std::cout << "\n=== Current Rules in System ===" << std::endl;
    for (int i = 0; i < ruleCount; i++) {
        std::cout << "Rule " << (i + 1) << ": IF " << ifParts[i] 
                  << " THEN " << thenParts[i] << std::endl;
    }
    std::cout << "Total rules: " << ruleCount << std::endl;
}

bool LogicEngine::searchForFact(std::string current, std::string target) {
    // If we found what we're looking for
    if (current == target) {
        return true;
    }
    
    // Look for rules where current fact is in the IF part
    for (int i = 0; i < ruleCount; i++) {
        if (ifParts[i] == current) {
            std::cout << "  Using rule: IF " << ifParts[i] << " THEN " << thenParts[i] << std::endl;
            if (searchForFact(thenParts[i], target)) {
                return true;
            }
        }
    }
    
    return false;
}

bool LogicEngine::checkRule(std::string startFact, std::string targetFact) {
    std::cout << "\n=== Checking Rule Inference ===" << std::endl;
    std::cout << "Can we prove: " << targetFact << " from: " << startFact << "?" << std::endl;
    std::cout << "Inference steps:" << std::endl;
    std::cout << "----------------" << std::endl;
    
    bool result = searchForFact(startFact, targetFact);
    
    std::cout << "----------------" << std::endl;
    if (result) {
        std::cout << "RESULT: YES - " << targetFact << " can be inferred from " << startFact << std::endl;
    } else {
        std::cout << "RESULT: NO - Cannot prove " << targetFact << " from " << startFact << std::endl;
    }
    
    return result;
}